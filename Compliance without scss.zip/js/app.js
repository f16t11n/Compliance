$(".compliance__left__items__item").click(function() {
    
    $(this).addClass('active').siblings().removeClass('active');

    $('.compliance__left__content h4').text('Jahidul islam');
});